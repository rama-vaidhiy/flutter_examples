import 'package:flutter/material.dart';

class ImageDisplayWidget extends StatelessWidget {
  const ImageDisplayWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: [
          Image(
            image: AssetImage(
              'images/mandala1.png',
            ),
          ),
          Image.asset('images/mandala2.png'),
        ],
      ),
    );
  }
}
