package com.example.navigating_pages;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
