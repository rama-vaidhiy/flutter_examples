import 'package:flutter/material.dart';

class GryffindorHouse extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Gryffindor House"),
      ),
      body: Column(
        children: [
          Center(
            child: Image.network(
              'https://static.wikia.nocookie.net/pottermore/images/1/16/Gryffindor_crest.png/revision/latest/scale-to-width-down/180?cb=20111112232412',
              height: 200,
            ),
          ),
          Divider(),
          RichText(
            text: TextSpan(
              text: """You might belong in Gryffindor,
Where dwell the brave at heart,
Their daring, nerve, and chivalry
Set Gryffindors apart;""",
              style: TextStyle(
                fontSize: 24.0,
                color: Colors.deepPurple,
                decorationColor: Colors.deepPurpleAccent,
                fontStyle: FontStyle.italic,
                fontWeight: FontWeight.normal,
              ),
            ),
          ),
          Divider(),
          TextButton(
            //all we need to do here to get back is to
            //call the pop on the Navigator's context.
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: Text("Home"),
          )
        ],
      ),
    );
  }
}
