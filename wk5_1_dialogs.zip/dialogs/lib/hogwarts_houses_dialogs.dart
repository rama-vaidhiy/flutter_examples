import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class HogwartsHouses extends StatefulWidget {
  const HogwartsHouses({Key? key}) : super(key: key);

  @override
  _HogwartsHousesState createState() => _HogwartsHousesState();
}

class _HogwartsHousesState extends State<HogwartsHouses> {
  String _dialogReturnValue = 'none';
  String _currentHouseName = 'any';

  //a generic function to create a dialog UI
  Widget createDialog(String houseName) {
    String imageURL = '';
    String houseFounderName = '';
    switch (houseName) {
      case 'Gryffindor':
        houseFounderName = 'Godric Gryffindor';
        imageURL =
            'https://static.wikia.nocookie.net/harrypotter/images/c/c4/Godric_Gryffindor.jpg';
        break;
      case 'Hufflepuff':
        houseFounderName = 'Helga Hufflepuff';
        imageURL =
            'https://static.wikia.nocookie.net/harrypotter/images/d/d7/Helga_Hufflepuff.jpg';
        break;
      case 'Ravenclaw':
        houseFounderName = 'Rowena Ravenclaw';
        imageURL =
            'https://static.wikia.nocookie.net/harrypotter/images/f/fd/Rowena_Ravenclaw_at_WWHP.jpg';
        break;
      case 'Slytherin':
        houseFounderName = 'Salazaar Slytherin';
        imageURL =
            'https://static.wikia.nocookie.net/harrypotter/images/8/86/Salazar_Slytherin_WWHP.jpg';
        break;
    }
    //this code creates a simple dialog and the
    //widgets that need to be shown in the dialog
    //with a ok and/or cancel button which will use
    //the navigator method to return an appropriate value.
    return SimpleDialog(
      children: [
        Column(
          children: [
            Image.network(
              imageURL,
              height: 200,
              width: 200,
            ),
            Divider(),
            Text(houseFounderName),
            Divider(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                //to get the options from the user
                //use SimpleDialogOption
                SimpleDialogOption(
                  onPressed: () {
                    //this returns the value of 'OK' to the caller.
                    Navigator.of(context).pop('OK');
                  },
                  child: Text('OK'),
                ),
                SimpleDialogOption(
                  onPressed: () {
                    //this returns the vlaue of 'Cancel' to the caller
                    Navigator.of(context).pop('Cancel');
                  },
                  child: Text('Whatever'),
                ),
              ],
            ),
          ],
        ),
      ],
    );
  }

  //Method to handle the button press on the names of the founders
  //what this does is it calls the showDialog with the buildcontext
  //and passes the function that actually creates the dialog.
  //once it returns back from the dialog it will also check for the
  //return value and update the main page with the return value from
  //that dialog.
  void _handleButtonPress(String houseName) async {
    //the showdialog ensures that the page built
    //is rendered as a dialog
    String result = await showDialog(
        context: context,
        builder: (BuildContext context) {
          //the creation of the dialog is
          //moved to a method to make it common
          return createDialog(houseName);
        });
    //make sure to add the changes that you need to show
    //in the main page in the setState, otherwise it will not be
    //refreshed.
    setState(() {
      _dialogReturnValue = result;
      _currentHouseName = houseName;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(10.0),
          child: Column(
            children: [
              RichText(
                text: TextSpan(
                  text: 'Founders of Hogwarts Houses',
                  style: TextStyle(
                    fontSize: 20.0,
                    color: Colors.indigo,
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ),
              Divider(),
              TextButton(
                //Launch the Dialog
                onPressed: () => _handleButtonPress('Gryffindor'),
                child: Text('Gryffindor'),
              ),
              Divider(),
              TextButton(
                //Launch the Dialog
                onPressed: () => _handleButtonPress('Hufflepuff'),
                child: Text('Hufflepuff'),
              ),
              Divider(),
              TextButton(
                //Launch the Dialog
                onPressed: () => _handleButtonPress('Ravenclaw'),

                child: Text('Ravenclaw'),
              ),
              Divider(),
              TextButton(
                //Launch the Dialog
                onPressed: () => _handleButtonPress('Slytherin'),
                child: Text('Slytherin'),
              ),
              Divider(),
              Text(
                  'You pressed $_dialogReturnValue on $_currentHouseName Dialog'),
              Divider(),
              ElevatedButton(
                  onPressed: () async {
                    await showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          //Trying to show an example
                          //of an alert dialog
                          //and see how its different from
                          //a normal showdialog
                          return AlertDialog(
                            title: Text('ALERT!'),
                            content: SingleChildScrollView(
                              child: ListBody(
                                children: [
                                  Text(
                                      'He Who Must No Be Named is watching you!'),
                                  Image.network(
                                    'https://pixabay.com/get/g61bec6c4dae865480c1f024f369ecd3b579c3a78970b5d9b62ebf887dde7d159fcca1aba4a17a59d8d39fc0e50304594_640.jpg',
                                    width: 200,
                                    height: 200,
                                  ),
                                ],
                              ),
                            ),
                            actions: [
                              TextButton(
                                onPressed: () {
                                  Navigator.pop(context);
                                },
                                child: Text('OK'),
                              ),
                            ],
                          );
                        });
                  },
                  child: Text('Alert me!'))
            ],
          ),
        ),
      ),
    );
  }
}
