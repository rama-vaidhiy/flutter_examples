import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
//TODO: uncomment this to see PathProvider's sample Home Page
//import 'showdirectories.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),

      //use this to show the path_provider's default UI
      //and the use of their APIs
      //TODO: uncomment the next line to see the PathProvider's home page
      // home: const PathProviderHomePage(title: 'Path Provider'),
      //uncomment this if if you want to try out the counter
      //file read and write to a counter.txt
      //TODO: If you want to see PathProviders home page, comment the below line
      //and look at the TODO: above
      home: MyHomePage(title: 'File I/O'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;

  //Method to retrieve the local documents directory of the device
  Future<String> get _localPath async {
    final directory = await getApplicationDocumentsDirectory();
    print('The directory retrieved is $directory.path');
    return directory.path;
  }

  //From the above directory retrieve the file that you want
  Future<File> get _localFile async {
    final path = await _localPath;
    //since we are storing the counter data we call it counter.txt
    return File('$path/counter.txt');
  }

  //read from the file
  Future<int> readCounter() async {
    try {
      final file = await _localFile;
      // Read the file
      final contents = await file.readAsString();
      print('Read the contents from the file as $contents');
      //we know that we are reading it as String
      //and the data stored is a number that we want
      //we have to parse it to an integer
      return int.parse(contents);
    } catch (e) {
      // If encountering an error, return 0
      return 0;
    }
  }

  //write the counter value to the file
  Future<File> writeCounter(int counter) async {
    final file = await _localFile;
    print('Writing the $counter data to the file');
    // Write the file
    return file.writeAsString('$counter');
  }

  //since we have written it to a file, when
  //we are initializing the UI we need to get the data
  //from the stored file
  @override
  void initState() {
    super.initState();
    readCounter().then((int value) {
      setState(() {
        _counter = value;
      });
    });
  }

  void _incrementCounter() {
    setState(() {
      _counter++;
    });
    writeCounter(_counter);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'You have pushed the button this many times:',
            ),
            Text(
              '$_counter',
              style: Theme.of(context).textTheme.headline4,
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _incrementCounter,
        tooltip: 'Increment',
        child: Icon(Icons.add),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
