package com.example.file_read_write;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
