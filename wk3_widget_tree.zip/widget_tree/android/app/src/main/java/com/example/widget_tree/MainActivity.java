package com.example.widget_tree;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
