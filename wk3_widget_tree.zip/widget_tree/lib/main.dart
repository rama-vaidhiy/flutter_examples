import 'package:flutter/material.dart';
import 'package:widget_tree/home.dart';
import 'package:widget_tree/widgethome.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Widget Tree',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: CommonWidgetsHome(),
    );
  }
}
