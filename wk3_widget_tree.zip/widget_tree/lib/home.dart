import 'package:flutter/material.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(
      //   //displayed before the title of the App
      //   //usually set to IconButton or BackButton
      //   leading: IconButton(
      //     icon: Icon(Icons.menu),
      //     onPressed: () {}, //no actions handled for now
      //   ),
      //   //the title of the App
      //   title: Text('Home'),
      //   //actions are displayed to the right of the title.
      //   //these can be IconButton or PopupMenuButton
      //   actions: <Widget>[
      //     IconButton(
      //       icon: Icon(Icons.search),
      //       onPressed: () {}, //no actions handled for now
      //     ),
      //     IconButton(
      //       icon: Icon(Icons.more_vert),
      //       onPressed: () {}, //no actions handled for now
      //     ),
      //   ],
      //   //flexibleSpace is stacked behind the Toolbar or TabBar
      //   // widget. The height is usually same as the AppBar widget’s height.
      //   // A background image is commonly applied to the
      //   // flexibleSpace property, but any widget, such as an Icon,
      //   // could be used.
      //   flexibleSpace: SafeArea(
      //     child: Icon(
      //       Icons.photo_camera,
      //       size: 75.0,
      //       color: Colors.white70,
      //     ),
      //   ),
      //   bottom: PreferredSize(
      //     child: Container(
      //       color: Colors.blue.shade100,
      //       height: 75.0,
      //       width: double.infinity,
      //       child: Center(
      //         child: Text('Bottom'),
      //       ),
      //     ),
      //     preferredSize: Size.fromHeight(75.0),
      //   ),
      // ),
      body: SafeArea(
        // child: container,//using method 1
        // child: _buildContainer(),//using method 2
        child: const MyContainer(), //using method 3
      ),

      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.refresh),
        onPressed: () {},
      ),
    );
  }
}

//Method 1
// assigning a widget using a constant
//making it final and using it as a variable
final container = Container(
  color: Colors.blue,
  height: 100.0,
  width: 200.0,
  child: Text(
    'Text inside a Container',
    textScaleFactor: 2.0,
  ),
);

//Method 2
// Return by general Widget Name
//or you can return as a Container
Widget _buildContainer() {
  print("Calls _buildContainer");
  return Container(
    color: Colors.blue,
    height: 100.0,
    width: 200.0,
    child: Text(
      'Text inside a Container',
      textScaleFactor: 2.0,
    ),
  );
}

//Method 3
//Create a widget class
class MyContainer extends StatelessWidget {
  //notice the use of const before the constructor
  const MyContainer({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    print('Rebuilds the MyContainer');
    return Container(
      color: Colors.blue,
      height: 100.0,
      width: 200.0,
      child: Text(
        'Text inside a Container',
        textScaleFactor: 2.0,
      ),
    );
  }
}
