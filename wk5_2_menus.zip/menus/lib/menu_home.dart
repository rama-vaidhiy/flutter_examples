import 'package:flutter/material.dart';

class MenuHomePage extends StatefulWidget {
  const MenuHomePage({Key? key}) : super(key: key);

  @override
  _MenuHomePageState createState() => _MenuHomePageState();
}

class _MenuHomePageState extends State<MenuHomePage> {
  HPSchoolItem? _chosenSchoolItem;
  String _petChoice = '';
  //method which returns the list of items to be displayed in the menu
  List<HPSchoolItem> getListOfSchoolItems() {
    return [
      HPSchoolItem(
        itemName: 'Books',
        itemIcon: ImageIcon(
          AssetImage('icons/books.png'),
        ),
      ),
      HPSchoolItem(
        itemName: 'Cauldron',
        itemIcon: ImageIcon(
          AssetImage('icons/cauldron.png'),
        ),
      ),
      HPSchoolItem(
        itemName: 'Pet',
        itemIcon: ImageIcon(
          AssetImage('icons/owlmail.png'),
        ),
      ),
      HPSchoolItem(
        itemName: 'Wand',
        itemIcon: ImageIcon(
          AssetImage('icons/wand.png'),
        ),
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    //build the list of schoolitems

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(20.0),
          child: Column(
            children: [
              Column(
                children: [
                  Text('Welcome to Diagon Alley'),
                  Divider(),
                  Row(
                    children: [
                      Text('What are you looking for?'),
                      Padding(
                        padding: EdgeInsets.only(right: 5.0),
                      ),
                      Center(
                        //This is the example of how to use
                        //a PopupMenuButton
                        //here we use the itemBuilder to create the
                        //display of menu items
                        //and the onSelected is handled just like
                        //we do for any list.
                        child: PopupMenuButton<HPSchoolItem>(
                          icon: Icon(Icons.view_list),
                          onSelected: ((valueSelected) {
                            setState(() {
                              _chosenSchoolItem = valueSelected;
                            });
                            print('valueSelected: ${valueSelected.itemName}');
                          }),
                          itemBuilder: (BuildContext context) {
                            return getListOfSchoolItems()
                                .map((HPSchoolItem schoolMenuItem) {
                              return PopupMenuItem<HPSchoolItem>(
                                value: schoolMenuItem,
                                child: Row(
                                  children: <Widget>[
                                    schoolMenuItem.itemIcon,
                                    Padding(
                                      padding: EdgeInsets.all(8.0),
                                    ),
                                    Text(schoolMenuItem.itemName),
                                  ],
                                ),
                              );
                            }).toList();
                          },
                        ),
                      ),
                    ],
                  ),
                  Divider(),
                  Text('You have chosen $_chosenSchoolItem'),
                  Divider(),
                ],
              ),
              Column(
                children: [
                  //This is an example of how to use a
                  //showMenu item to programmatically add
                  //a list of items as and when required
                  //and display it. This can be used
                  //when you have a varying choice based
                  //on a specific selection on the screen
                  //we do this just like we do the dialogs
                  //where the dialog is built when the
                  //showDialog is called.
                  ElevatedButton(
                    child: Text('Your Pet Choice'),
                    onPressed: () async {
                      String? result = await showMenu<String>(
                        context: context,
                        position: RelativeRect.fromLTRB(0, 0, 0, 0),
                        items: [
                          //The same old PopupMenuItems
                          //just like above
                          PopupMenuItem(
                            value: 'mouse',
                            child: Text('Mouse'),
                          ),
                          PopupMenuItem(
                            value: 'toad',
                            child: Text('Toad'),
                          ),
                          //You can also add a divider
                          PopupMenuDivider(),
                          //Example to show how a Checked PopupMenu Item
                          //looks like
                          CheckedPopupMenuItem(
                            value: 'owl',
                            checked: true,
                            child: Text('Owl'),
                          ),
                          CheckedPopupMenuItem(
                            value: 'dragon',
                            child: Text('Dragon'),
                          )
                        ],
                        initialValue: 'owl',
                      );
                      print(result);
                      setState(() {
                        _petChoice = result.toString();
                      });
                    },
                  ),
                  Text('You like $_petChoice'),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class HPSchoolItem {
  final String itemName;
  final ImageIcon itemIcon;
  HPSchoolItem({required this.itemName, required this.itemIcon});

  @override
  String toString() {
    return itemName;
  }
}
