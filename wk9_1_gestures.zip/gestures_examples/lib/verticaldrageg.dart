import 'package:flutter/material.dart';

class VerDrag extends StatefulWidget {
  const VerDrag({Key? key}) : super(key: key);

  @override
  _VerDragState createState() => _VerDragState();
}

class _VerDragState extends State<VerDrag> {
  bool _dragging = false;
  Offset _move = Offset.zero;
  int _dragCount = 0;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onVerticalDragStart: (DragStartDetails details) {
        setState(() {
          print(details);
          _move = Offset.zero;
          _dragging = true;
        });
      },
      onVerticalDragUpdate: (DragUpdateDetails details) {
        setState(() {
          print(details);
          _move += details.delta;
        });
      },
      onVerticalDragEnd: (DragEndDetails details) {
        setState(() {
          print(details);
          _dragging = false;
          _dragCount++;
        });
      },
      child: Container(
        color: Colors.grey,
        child: Center(
          child: Transform.translate(
            offset: _move,
            child: Text(
              _dragging ? "DRAGGING!" : "Drags: $_dragCount",
              style: Theme.of(context).textTheme.bodyText1,
            ),
          ),
        ),
      ),
    );
  }
}
