import 'package:flutter/material.dart';

class HorDrag extends StatefulWidget {
  const HorDrag({Key? key}) : super(key: key);

  @override
  _HorDragState createState() => _HorDragState();
}

class _HorDragState extends State<HorDrag> {
  bool _dragging = false;
  Offset _move = Offset.zero;
  int _dragCount = 0;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onHorizontalDragStart: (DragStartDetails details) {
        setState(() {
          print(details);
          _move = Offset.zero;
          _dragging = true;
        });
      },
      onHorizontalDragUpdate: (DragUpdateDetails details) {
        setState(() {
          print(details);
          _move += details.delta;
        });
      },
      onHorizontalDragEnd: (DragEndDetails details) {
        setState(() {
          print(details);
          _dragging = false;
          _dragCount++;
        });
      },
      child: Container(
        color: Colors.grey,
        child: Center(
          child: Transform.translate(
            offset: _move,
            child: Text(
              _dragging ? "DRAGGING!" : "Drags: $_dragCount",
              style: Theme.of(context).textTheme.bodyText1,
            ),
          ),
        ),
      ),
    );
  }
}
