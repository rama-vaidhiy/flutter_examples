import 'package:flutter/material.dart';

class PanWidget extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _PanWidgetState();
  }
}

class _PanWidgetState extends State<PanWidget> {
  bool _dragging = false;
  Offset _move = Offset.zero;
  int _dragCount = 0;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onPanStart: (DragStartDetails details) {
        setState(() {
          print(details);
          _move = Offset.zero;
          _dragging = true;
        });
      },
      onPanUpdate: (DragUpdateDetails details) {
        setState(() {
          print(details);
          _move += details.delta;
        });
      },
      onPanEnd: (DragEndDetails details) {
        setState(() {
          print(details);
          _dragging = false;
          _dragCount++;
        });
      },
      child: Container(
        color: Colors.grey,
        child: Center(
          child: Transform.translate(
            offset: _move,
            child: Text(
              _dragging ? "DRAGGING!" : "Drags: $_dragCount",
              style: Theme.of(context).textTheme.bodyText1,
            ),
          ),
        ),
      ),
    );
  }
}
