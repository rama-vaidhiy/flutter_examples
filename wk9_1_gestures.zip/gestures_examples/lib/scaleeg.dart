import 'package:flutter/material.dart';

class ScaleWidget extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _ScaleWidgetState();
  }
}

class _ScaleWidgetState extends State<ScaleWidget> {
  bool _resizing = false;
  double _scale = 1.0;
  int _scaleCount = 0;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onScaleStart: (ScaleStartDetails details) {
        setState(() {
          print(details);
          _scale = 1.0;
          _resizing = true;
        });
      },
      onScaleUpdate: (ScaleUpdateDetails details) {
        print(details);
        setState(() {
          _scale = details.scale;
        });
      },
      onScaleEnd: (ScaleEndDetails details) {
        print(details);
        setState(() {
          _resizing = false;
          _scaleCount++;
        });
      },
      child: Container(
        color: Colors.grey,
        child: Center(
          child: Transform.scale(
            scale: _scale,
            child: Text(
              _resizing ? "RESIZING!" : "Scale count: $_scaleCount",
              style: Theme.of(context).textTheme.bodyText1,
            ),
          ),
        ),
      ),
    );
  }
}
