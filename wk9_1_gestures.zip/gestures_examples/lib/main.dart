import 'package:flutter/material.dart';
import 'gestures1.dart';
import 'horizontaldrageg.dart';
import 'verticaldrageg.dart';
import 'paneg.dart';
import 'scaleeg.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        //change the body to do the kind of gesture
        // you want to test.
        body: Padding(
          padding: const EdgeInsets.all(25.0),
          child: Center(
            child: ScaleWidget(),
          ),
        ),
      ),
    );
  }
}
