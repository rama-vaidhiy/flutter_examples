import 'package:flutter/material.dart';

class GesturesTapsPress extends StatefulWidget {
  const GesturesTapsPress({Key? key}) : super(key: key);

  @override
  _GesturesTapsPressState createState() => _GesturesTapsPressState();
}

class _GesturesTapsPressState extends State<GesturesTapsPress> {
  int _longPressCounter = 0;
  int _tapCounter = 0;
  int _doubleTapCounter = 0;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onLongPress: () {
        setState(() {
          _longPressCounter++;
        });
      },
      onTap: () {
        setState(() {
          _tapCounter++;
        });
      },
      onDoubleTap: () {
        setState(() {
          _doubleTapCounter++;
        });
      },
      child: Container(
        color: Colors.grey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ElevatedButton(
              onPressed: () {},
              child: Text('Sample'),
            ),
            Center(
              child: Text(
                "Tap count: $_tapCounter",
                style: Theme.of(context).textTheme.bodyText1,
              ),
            ),
            Center(
              child: Text(
                "Double Tap count: $_doubleTapCounter",
                style: Theme.of(context).textTheme.bodyText1,
              ),
            ),
            Center(
              child: Text(
                "LongPress count: $_longPressCounter",
                style: Theme.of(context).textTheme.bodyText1,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
