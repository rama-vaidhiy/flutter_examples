import 'package:flutter/material.dart';
import 'rotationanimation.dart';
import 'scaleanimations.dart';
import 'translateanimations.dart';
import 'composedanimations.dart';
import 'customtweenanimations.dart';
import 'animationbuildereg.dart';
import 'animatedwidgeteg.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Animation Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      //home: RotationAnimations(),
      // home: ScaleAnimations(),
      // home: TranslateAnimations(),
      // home: ComposedAnimations(),
      // home: CustomTweenAnimations(),
      home: LogoAnimatedBuilderApp(),
      //home: LogoAnimatedWidgetApp(),
    );
  }
}
