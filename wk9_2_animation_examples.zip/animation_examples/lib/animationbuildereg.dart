import 'package:flutter/material.dart';
import 'dart:math' as math;

// const _toRadians = (math.pi / 180.0);
//
// class AnimationBuilderAnimations extends StatefulWidget {
//   @override
//   _AnimationBuilderAnimationsState createState() =>
//       _AnimationBuilderAnimationsState();
// }
//
// class _AnimationBuilderAnimationsState extends State<AnimationBuilderAnimations>
//     with SingleTickerProviderStateMixin {
//   late AnimationController _controller;
//   late Animation<ButtonTransformation> _animation;
//
//   @override
//   void initState() {
//     super.initState();
//
//     _animation = createAnimation();
//     _controller.forward();
//   }
//
//   @override
//   void dispose() {
//     _controller.dispose();
//     super.dispose();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       color: Colors.grey,
//       child: Center(
//         child: ButtonTransition(
//           animation: _animation,
//           child: ElevatedButton(
//             child: Text("AnimatedBuilder animation"),
//             onPressed: () {
//               if (_controller.status == AnimationStatus.completed) {
//                 _controller.reverse();
//               } else if (_controller.status == AnimationStatus.dismissed) {
//                 _controller.forward();
//               }
//             },
//           ),
//         ),
//       ),
//     );
//   }
//
//   createAnimation() {
//     _controller = AnimationController(
//       vsync: this,
//       debugLabel: "animations demo",
//       duration: Duration(seconds: 3),
//     );
//
//     return _controller.drive(
//       CustomTween(
//         begin: ButtonTransformation.none,
//         end: ButtonTransformation(
//           angle: 360.0,
//           offset: Offset(70, 200),
//           scale: 2.0,
//         ),
//       ),
//     );
//   }
// }
//
// class ButtonTransition extends StatelessWidget {
//   final Animation<ButtonTransformation> _animation;
//   final ElevatedButton child;
//
//   const ButtonTransition({
//     required Animation<ButtonTransformation> animation,
//     required this.child,
//   }) : _animation = animation;
//
//   @override
//   Widget build(BuildContext context) {
//     return AnimatedBuilder(
//       animation: _animation,
//       child: child,
//       builder: (context, child) => Transform(
//         transform: Matrix4.translationValues(
//           _animation.value.offset.dx,
//           _animation.value.offset.dy,
//           0,
//         )
//           ..rotateZ(_animation.value.angle * _toRadians)
//           ..scale(_animation.value.scale, _animation.value.scale),
//         child: child,
//       ),
//     );
//   }
// }
//
// class ButtonTransformation {
//   final double scale;
//   final double angle;
//   final Offset offset;
//
//   ButtonTransformation(
//       {required this.scale, required this.angle, required this.offset});
//
//   ButtonTransformation operator -(ButtonTransformation other) =>
//       ButtonTransformation(
//         scale: scale - other.scale,
//         angle: angle - other.angle,
//         offset: offset - other.offset,
//       );
//
//   ButtonTransformation operator +(ButtonTransformation other) =>
//       ButtonTransformation(
//         scale: scale + other.scale,
//         angle: angle + other.angle,
//         offset: offset + other.offset,
//       );
//
//   ButtonTransformation operator *(double t) => ButtonTransformation(
//         scale: scale * t,
//         angle: angle * t,
//         offset: offset * t,
//       );
//
//   static ButtonTransformation get none => ButtonTransformation(
//         scale: 1.0,
//         angle: 0.0,
//         offset: Offset.zero,
//       );
// }
//
// class CustomTween extends Tween<ButtonTransformation> {
//   CustomTween(
//       {required ButtonTransformation begin, required ButtonTransformation end})
//       : super(
//           begin: begin,
//           end: end,
//         );
//
//   @override
//   lerp(double t) {
//     return super.lerp(t);
//   }
// }

// #docregion LogoWidget
class LogoWidget extends StatelessWidget {
  const LogoWidget({Key? key}) : super(key: key);

  // Leave out the height and width so it fills the animating parent
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 10),
      child: const FlutterLogo(),
    );
  }
}
// #enddocregion LogoWidget

// #docregion GrowTransition
class GrowTransition extends StatelessWidget {
  const GrowTransition({required this.child, required this.animation, Key? key})
      : super(key: key);

  final Widget child;
  final Animation<double> animation;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: AnimatedBuilder(
        animation: animation,
        builder: (context, child) {
          return SizedBox(
            height: animation.value,
            width: animation.value,
            child: child,
          );
        },
        child: child,
      ),
    );
  }
}
// #enddocregion GrowTransition

class LogoAnimatedBuilderApp extends StatefulWidget {
  const LogoAnimatedBuilderApp({Key? key}) : super(key: key);

  @override
  _LogoAnimatedBuilderAppState createState() => _LogoAnimatedBuilderAppState();
}

// #docregion print-state
class _LogoAnimatedBuilderAppState extends State<LogoAnimatedBuilderApp>
    with SingleTickerProviderStateMixin {
  late Animation<double> animation;
  late AnimationController controller;

  @override
  void initState() {
    super.initState();
    controller =
        AnimationController(duration: const Duration(seconds: 2), vsync: this);
    animation = Tween<double>(begin: 0, end: 300).animate(controller);
    controller.forward();
  }
  // #enddocregion print-state

  @override
  Widget build(BuildContext context) {
    return GrowTransition(
      child: const LogoWidget(),
      animation: animation,
    );
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }
// #docregion print-state
}
