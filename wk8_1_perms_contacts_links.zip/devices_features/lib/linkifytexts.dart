import 'package:flutter/material.dart';
import 'package:flutter_linkify/flutter_linkify.dart';
import 'dart:async';

import 'package:url_launcher/url_launcher.dart';

class LinkifyWidgets extends StatefulWidget {
  const LinkifyWidgets({Key? key}) : super(key: key);

  @override
  _LinkifyWidgetsState createState() => _LinkifyWidgetsState();
}

class _LinkifyWidgetsState extends State<LinkifyWidgets> {
  Future<void> _onOpen(LinkableElement link) async {
    if (await canLaunch(link.url)) {
      await launch(link.url);
    } else {
      throw 'Could not launch $link';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Using Linkify'),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Text('Non-Selectable Linkify Text'),
          Expanded(
            flex: 2,
            child: Center(
              child: Linkify(
                onOpen: _onOpen,
                textScaleFactor: 2.0,
                text:
                    "Welcome to https://www.wizardingworld.com/\n\nMail: m.mcgonagall@hogwarts.com",
              ),
            ),
          ),
          Text('Selectable Linkify Text'),
          Expanded(
            flex: 2,
            child: Center(
              child: SelectableLinkify(
                onOpen: _onOpen,
                textScaleFactor: 2.0,
                text:
                    "Made by https://www.wizardingworld.com\n\nMail: m.mcgonagall@hogwarts.com",
              ),
            ),
          ),
        ],
      ),
    );
  }
}
