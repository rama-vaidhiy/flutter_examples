import 'package:flutter/material.dart';
import 'package:contact_picker/contact_picker.dart';
import 'package:permission_handler/permission_handler.dart';

//this uses contact_picker for which you have to set
//the run time property --no-sound-null-safety
//if not it wont compile.
class PickAContactWidget extends StatefulWidget {
  @override
  _PickAContactWidgetState createState() => new _PickAContactWidgetState();
}

class _PickAContactWidgetState extends State<PickAContactWidget> {
  final ContactPicker _contactPicker = new ContactPicker();
  bool isContactsOn = false;
  Contact? _contact;

  @override
  void initState() {
    checkContactsPermission();
  }

  Future<void> checkContactsPermission() async {
    final serviceStatus = await Permission.contacts.isGranted;
    isContactsOn = serviceStatus == ServiceStatus.enabled.isEnabled;
    print(
        'checkContactsPermission: Service Status $serviceStatus contactsOn $isContactsOn');
  }

  Future<void> requestContactPermission() async {
    final status = await Permission.contacts.request();
    if (status == PermissionStatus.granted) {
      print('Permission Granted');
    } else if (status == PermissionStatus.denied) {
      print('Permission denied');
      await openAppSettings();
    } else if (status == PermissionStatus.permanentlyDenied) {
      print('Permission Permanently Denied');
      await openAppSettings();
    }
    print('requestContactPermission: Status after request  : $status');
    final serviceStatus = await Permission.contacts.isGranted;
    setState(() {
      isContactsOn = serviceStatus == ServiceStatus.enabled.isEnabled;
      print(
          'requestContactPermission: Service Status $serviceStatus contactsOn $isContactsOn');
    });
  }

  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      home: new Scaffold(
        appBar: new AppBar(
          title: new Text('Using Contact Picker'),
        ),
        body: new Center(
          child: new Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              // !isContactsOn
              //     ? TextButton(
              //         onPressed: () {
              //           requestContactPermission();
              //         },
              //         child: Text('Request Contacts Permission'),
              //       )
              //     : Text('Contacts Permissions Enabled'),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Column(
                    children: [
                      new Text(
                        _contact == null
                            ? 'No contact selected.'
                            : _contact!.fullName.toString(),
                        textScaleFactor: 2.0,
                      ),
                      new Text(
                        _contact == null
                            ? 'No contact selected.'
                            : _contact!.phoneNumber.number,
                        textScaleFactor: 1.5,
                      ),
                    ],
                  ),
                  new IconButton(
                    icon: Icon(Icons.book),
                    onPressed: () async {
                      Contact? contact = await _contactPicker.selectContact();
                      setState(() {
                        _contact = contact;
                        print(_contact);
                      });
                    },
                    tooltip: 'PhoneBook',
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
