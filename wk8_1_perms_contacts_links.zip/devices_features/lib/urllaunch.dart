import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:url_launcher/link.dart';
//More examples available in https://pub.dev/packages/url_launcher

class MyURLLauncherBasic extends StatefulWidget {
  const MyURLLauncherBasic({Key? key}) : super(key: key);

  @override
  _MyURLLauncherBasicState createState() => _MyURLLauncherBasicState();
}

class _MyURLLauncherBasicState extends State<MyURLLauncherBasic> {
  String _phone = '+44 (0)1792 205678';
  //uses the default browser set for the device
  //if it can be launched successfully, it will launch it
  //else it will throw an exception that it couldn't.
  Future<void> _launchInBrowser(String url) async {
    if (await canLaunch(url)) {
      await launch(
        url,
      );
    } else {
      throw 'Could not launch $url';
    }
  }

  //making a phone call using the URL Launcher APIs
  Future<void> _makePhoneCall(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('URL Launch Examples'),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          //this is used to launch a URL using the default browser

          GestureDetector(
            onTap: () {
              _launchInBrowser('https://www.wizardingworld.com/');
            },
            child: Center(
              child: Text(
                'Click to launch a URL',
                textScaleFactor: 2.0,
                style: TextStyle(color: Colors.blue),
              ),
            ),
          ),
          Divider(
            color: Colors.red,
          ),
          //the next two widgets are used to make a phone call
          Center(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: TextField(
                onChanged: (String text) => _phone = text,
                decoration: const InputDecoration(
                    labelText: 'Phone Number',
                    hintText: 'Input the phone number to launch'),
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () => setState(() {
              _makePhoneCall('tel:$_phone');
            }),
            child: const Text('Make phone call'),
          ),
          //Next widget uses LINK widget to launch a URL
          Divider(
            color: Colors.red,
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Link(
              uri: Uri.parse(
                  'https://pub.dev/documentation/url_launcher/latest/link/link-library.html'),
              target: LinkTarget.blank,
              builder: (ctx, openLink) {
                return TextButton.icon(
                  onPressed: openLink,
                  label: Text(
                    'Link Widget documentation',
                    textScaleFactor: 2.0,
                  ),
                  icon: Icon(Icons.read_more),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
