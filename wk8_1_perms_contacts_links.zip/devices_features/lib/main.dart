import 'package:flutter/material.dart';
import 'urllaunch.dart';
import 'linkifytexts.dart';
import 'importcontact.dart';
import 'package:baseflow_plugin_template/baseflow_plugin_template.dart';
import 'package:permission_handler/permission_handler.dart';
import 'testpermissions.dart';

void main() {
  //use this to open up a page where you can see what
  //apps are set with what permissions
  // runApp(BaseflowPluginExample(
  //     pluginName: 'Permission Handler',
  //     githubURL: 'https://github.com/Baseflow/flutter-permission-handler',
  //     pubDevURL: 'https://pub.dev/packages/permission_handler',
  //     pages: [PermissionHandlerWidget.createPage()]));
  //for any other examples use this
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Device Features Demo',
      debugShowCheckedModeBanner: false,
      // home: MyURLLauncherBasic(),
      //home: LinkifyWidgets(),
      home: PickAContactWidget(),
    );
  }
}
