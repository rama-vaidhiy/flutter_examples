package com.example.devices_features;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
