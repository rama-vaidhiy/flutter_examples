import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'xml_home_page.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      //TODO: use the MyHomePage for JSON demo
      // home: MyHomePage(title: 'Flutter JSON Demo Page'),
      //TODO: use the XMLHomePage for XML demo
      home: XMLHomePage(title: 'Flutter XML Demo Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  List _hpstaff = [];

  //Get the local App Document Directory
  Future<String> get _localPath async {
    final directory = await getApplicationDocumentsDirectory();
    return directory.path;
  }

  //Get the file
  Future<File> get _localFile async {
    final path = await _localPath;
    return File('$path/hp_staff.json');
  }

  //Read contents from the JSON file
  //which is in assets/hp_staff.json
  //remember the assets file is mainly used for
  //loading something for reading purposes
  //likes the settings of an application and such
  Future<void> readJSONFileFromAssets() async {
    //load the file using the assetbundle
    final String response = await rootBundle.loadString('assets/hp_staff.json');
    //use the flutter's default available API to decode/encode
    final data = await jsonDecode(response);
    setState(() {
      _hpstaff = data;
    });
  }

  //Read contents from the JSON file
  //which is in the local directory file
  Future<void> readJSONFileFromLocalFile() async {
    try {
      final file = await _localFile;
      // Read the file and store its contents as String
      final contents = await file.readAsString();
      setState(() {
        //now use the dart:convert's jsonDecode
        //to convert the string to json format
        //in this case, we know it will be a list of
        //names but you might want to make it generic
        //by having the data format as var
        _hpstaff = jsonDecode(contents);
      });
    } catch (e) {
      //ignoring the error for now
      _hpstaff = [];
    }
  }

  //Writing the json file to the local file in the app
  //documents directory using the path provider APIs
  Future<void> writeToJSONLocalFile(int index) async {
    setState(() {
      _hpstaff.removeAt(index);
    });
    //get the local file to where we can write this data to
    final file = await _localFile;
    // Write the file with the String format of the json data
    //which you can do by using dart:convert's jsonEncode API
    file.writeAsStringSync(jsonEncode(_hpstaff));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Row(
              children: [
                TextButton(
                    onPressed: readJSONFileFromAssets,
                    child: Text('Load HP Staff from Assets')),
                TextButton(
                    onPressed: readJSONFileFromLocalFile,
                    child: Text('Load HP Staff from Local File')),
              ],
            ),
            //we are trying to create a Listview with all the names
            //of the hp staff but only if the staff list if correctly
            //loaded, if not then we return just a container
            _hpstaff.length > 0
                ? Expanded(
                    child: ListView.builder(
                      itemCount: _hpstaff.length,
                      itemBuilder: (context, index) {
                        return Card(
                          margin: EdgeInsets.all(10),
                          child: ListTile(
                            leading: Text(_hpstaff[index]['house']),
                            title: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Text(_hpstaff[index]['name']),
                                IconButton(
                                  onPressed: () => writeToJSONLocalFile(index),
                                  icon: Icon(Icons.delete),
                                ),
                              ],
                            ),
                            subtitle:
                                Text('Played by ' + _hpstaff[index]['actor']),
                          ),
                        );
                      },
                    ),
                  )
                : Container(),
          ],
        ),
      ),
    );
  }
}
