import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:xml/xml.dart';

class XMLHomePage extends StatefulWidget {
  XMLHomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  _XMLHomePageState createState() => _XMLHomePageState();
}

class _XMLHomePageState extends State<XMLHomePage> {
  List<String> _hpstaff = [];

  //Get the local App Document Directory
  Future<String> get _localPath async {
    final directory = await getApplicationDocumentsDirectory();
    return directory.path;
  }

  //Get the file
  Future<File> get _localFile async {
    final path = await _localPath;
    return File('$path/hp_staff.xml');
  }

  //Read contents from the JSON file
  //which is in assets/hp_staff.json
  //remember the assets file is mainly used for
  //loading something for reading purposes
  //likes the settings of an application and such
  Future<void> readJSONFileFromAssets() async {
    //load the file using the assetbundle
    final String response = await rootBundle.loadString('assets/hp_staff.xml');
    XmlDocument document = parse(response);
    //Use the XML packages API to parse the names only for now
    final data = document.findAllElements('name').toList();
    int index = 0;
    setState(() {
      data.forEach((element) {
        _hpstaff.insert(index++, element.text);
      });
      //_hpstaff = data;
      // print(data);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Row(
              children: [
                TextButton(
                    onPressed: readJSONFileFromAssets,
                    child: Text('Load HP Staff from Assets')),
              ],
            ),
            //we are trying to create a Listview with all the names
            //of the hp staff but only if the staff list if correctly
            //loaded, if not then we return just a container
            _hpstaff.length > 0
                ? Expanded(
                    child: ListView.builder(
                      itemCount: _hpstaff.length,
                      itemBuilder: (context, index) {
                        return Card(
                          margin: EdgeInsets.all(10),
                          child: ListTile(
                            title: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Text(_hpstaff[index]),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  )
                : Container(),
          ],
        ),
      ),
    );
  }
}
