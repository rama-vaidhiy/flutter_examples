package com.example.navigation_with_data;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
