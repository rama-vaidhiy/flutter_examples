import 'package:flutter/material.dart';
import 'package:navigation_with_data/home_page_sendandreceive.dart';
import 'package:navigation_with_data/home_page_sendrecv_namedroute.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // // This widget is the root of your application.
  // //Method 1: To use the data object to pass between
  // //screens, to send and receive data
  // @override
  // Widget build(BuildContext context) {
  //   return MaterialApp(
  //     title: 'Flutter Demo',
  //     theme: ThemeData(
  //       primarySwatch: Colors.blue,
  //     ),
  //     home: HomePageSendReceiveData(),
  //   );
  // }
  //Method 2: To use the named routes and
  //passing data using RouteSettings and such
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      //home: HomePageSendRecvNamedRoute(),
      //setup the routes here
      routes: {
        '/': (context) => HomePageSendRecvNamedRoute(),
        '/gcommon': (context) => GryffindorCommonRoomNamedRoute(),
      },
      //you can also check and pass data using onGenerateRoute
      //Let us say that we want to call a page class which uses
      //a parameter but hasnt been set in the routes,
      //we can still call that page using pushNamed and send an
      //argument and handle the route direction here
      //in this case, unlike the GryffindorCommonRoomNamedRoute
      //which doesnt take in any constructor arguments
      //GryffindorCommonRoom takes in a WizardDetails argument
      //which we say in the previous example.
      //so we use this onGenerateRoute to get the RouteSettings
      //extract the argument, construct the object necessary and
      //call the page using the same old MaterialPageRoute
      onGenerateRoute: (settings) {
        if (settings.name == '/gcommonnonnamedroute') {
          final args = settings.arguments as Map;
          return MaterialPageRoute(builder: (BuildContext context) {
            final WizardDetails wizardDetails = WizardDetails();
            wizardDetails.name = args['name'];
            wizardDetails.password = args['password'];
            print(wizardDetails.name);
            return GryffindorCommonRoom(wizardDetails);
          });
        }
      },
    );
  }
}
