import 'package:flutter/material.dart';
import 'package:navigation_with_data/home_page_sendandreceive.dart';

class HomePageSendRecvNamedRoute extends StatefulWidget {
  const HomePageSendRecvNamedRoute({Key? key}) : super(key: key);

  @override
  _HomePageSendRecvNamedRouteState createState() =>
      _HomePageSendRecvNamedRouteState();
}

class _HomePageSendRecvNamedRouteState
    extends State<HomePageSendRecvNamedRoute> {
  WizardDetailsNamedRoute _wizardDetails = new WizardDetailsNamedRoute();
  TextEditingController _nameController = TextEditingController();
  TextEditingController _pwdController = TextEditingController();

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _pwdController.dispose();
    super.dispose();
  }

  void _launchCommonRoomPage() async {
    _wizardDetails.name = _nameController.text;
    _wizardDetails.password = _pwdController.text;
    //we are launching the common room screen by
    //calling the pushNamed for NamedRoutes
    //and pass the object as argument
    Navigator.pushNamed(context, '/gcommon', arguments: _wizardDetails);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(20.0),
          child: Column(
            children: [
              TextField(
                decoration: InputDecoration(
                  labelText: 'What\'s your name, wizard?',
                ),
                controller: _nameController,
              ),
              Divider(),
              TextField(
                obscureText: true,
                decoration: InputDecoration(
                  labelText: 'What\'s the password',
                ),
                controller: _pwdController,
              ),
              Divider(),
              ElevatedButton(
                onPressed: _launchCommonRoomPage,
                child: Text('Alohomora!'),
              ),
              Divider(),
              ElevatedButton(
                onPressed: () {
                  //this is another example of how to call
                  //a page which is not part of the routes set in the
                  //MaterialApp but we still want to go to that screen
                  //this is the screen that we used in the previous example
                  //to pass data using constructor.
                  //illustrating a slightly different way of passing
                  //the data using a map.
                  Map dataMap = Map();
                  dataMap.putIfAbsent('name', () => _nameController.text);
                  dataMap.putIfAbsent('password', () => _pwdController.text);
                  Navigator.pushNamed(context, "/gcommonnonnamedroute",
                      arguments: dataMap);
                },
                child: Text('Alohomora with NonNamed Route!'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

//Class to store the data to be passed around the pages
class WizardDetailsNamedRoute {
  String name = '';
  String password = '';

  WizardDetailsNamedRoute({name, password});
}

//The Screen which shows the welcome to the wizard by
//using the data that is being passed.
class GryffindorCommonRoomNamedRoute extends StatefulWidget {
  GryffindorCommonRoomNamedRoute();

  @override
  _GryffindorCommonRoomNamedRouteState createState() =>
      _GryffindorCommonRoomNamedRouteState();
}

class _GryffindorCommonRoomNamedRouteState
    extends State<GryffindorCommonRoomNamedRoute> {
  _GryffindorCommonRoomNamedRouteState();
  String welcomeText = '';

  @override
  Widget build(BuildContext context) {
    //here in the build context
    //we received the object passed using ModalRoute.of method
    //but make sure to cast the object to its right class
    //in this case we sent a WizardDetailsNamedRoute type of object
    //so it should be cast using 'as' as such.
    //if you passed string us as String and so on and so forth.
    final _wizardDetails =
        ModalRoute.of(context)!.settings.arguments as WizardDetailsNamedRoute;
    welcomeText =
        'Welcome to the Gryffindor Common room (Named)! ' + _wizardDetails.name;
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.all(10.0),
        child: Column(
          children: [
            Text('$welcomeText'),
            TextButton(
              onPressed: () {
                //As part of returning to the previous page
                //we can also send the data back
                //using the same object through which we received the
                //data. Just add it as part of pop method
                //and deal with it in the return of the push method in the
                //caller
                _wizardDetails.name = 'The Boy That Lived';
                _wizardDetails.password = '';
                Navigator.of(context).pop(_wizardDetails);
              },
              child: Text('Return'),
            )
          ],
        ),
      ),
    );
  }
}
