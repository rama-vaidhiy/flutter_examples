import 'package:flutter/material.dart';

class HomePageSendReceiveData extends StatefulWidget {
  const HomePageSendReceiveData({Key? key}) : super(key: key);

  @override
  _HomePageSendReceiveDataState createState() =>
      _HomePageSendReceiveDataState();
}

class _HomePageSendReceiveDataState extends State<HomePageSendReceiveData> {
  WizardDetails _wizardDetails = new WizardDetails();
  TextEditingController _nameController = TextEditingController();
  TextEditingController _pwdController = TextEditingController();

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _pwdController.dispose();
    super.dispose();
  }

  void _launchCommonRoomPage() async {
    //Sending the data via the Constructor of the Page
    //We are updating the object which has the inputs
    //and send them when we call the Navigator.push
    //when the pop is called from the other end, it might
    //send some data back too.
    WizardDetails result = await Navigator.of(context).push(
      MaterialPageRoute(builder: (BuildContext context) {
        _wizardDetails.name = _nameController.text;
        _wizardDetails.password = _pwdController.text;
        //the data to the page is sent via its constructor
        return GryffindorCommonRoom(_wizardDetails);
      }),
    );
    //if it is not null then you can see
    //what data is being sent back and update it accordingly
    if (result != null) {
      setState(() {
        _wizardDetails = result;
        _nameController.text = result.name;
        _pwdController.text = result.password;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(20.0),
          child: Column(
            children: [
              TextField(
                decoration: InputDecoration(
                  labelText: 'What\'s your name, wizard?',
                ),
                controller: _nameController,
              ),
              Divider(),
              TextField(
                obscureText: true,
                decoration: InputDecoration(
                  labelText: 'What\'s the password',
                ),
                controller: _pwdController,
              ),
              Divider(),
              ElevatedButton(
                onPressed: _launchCommonRoomPage,
                child: Text('Alohomora!'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

//Class to store the data to be passed around the pages
class WizardDetails {
  String name = '';
  String password = '';

  WizardDetails({name, password});
}

//The Screen which shows the welcome to the wizard by
//using the data that is being passed.
class GryffindorCommonRoom extends StatefulWidget {
  final WizardDetails wizardDetails;
  GryffindorCommonRoom(this.wizardDetails);

  @override
  _GryffindorCommonRoomState createState() =>
      _GryffindorCommonRoomState(wizardDetails);
}

class _GryffindorCommonRoomState extends State<GryffindorCommonRoom> {
  WizardDetails _wizardDetails;
  _GryffindorCommonRoomState(this._wizardDetails);
  String welcomeText = '';

  @override
  void initState() {
    super.initState();
    welcomeText =
        'Welcome to the Gryffindor Common Room!' + _wizardDetails.name;
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.all(10.0),
        child: Column(
          children: [
            Text('$welcomeText'),
            TextButton(
              onPressed: () {
                //As part of returning to the previous page
                //we can also send the data back
                //using the same object through which we received the
                //data. Just add it as part of pop method
                //and deal with it in the return of the push method in the
                //caller
                _wizardDetails.name = 'The Boy That Lived';
                _wizardDetails.password = '';
                Navigator.of(context).pop(_wizardDetails);
              },
              child: Text('Return'),
            )
          ],
        ),
      ),
    );
  }
}
